

function makeTrain() {
      if (game.train.json == null) {
            alert("fail to get train JSON \n "+game.train.json)
      }
      
      // make the folder
      game.train.data = doc.createElement("div")
      game.train.data.style.cssText = "position: absolute; scale:"+game.train.json.sprites.body[1]["scale"]+"; z-index:3; left: "+(
            game.train.json.sprites.body[1]["position"][0] - 500
      )+"px; top:"+(
            game.train.json.sprites.body[1]["position"][1] + 10
      )+"px;"
      
      // make the body
      t = doc.createElement("img");
      t.id = "train:body"
      t.src = "main/Trains/"+game.train.json.folder+"/"+game.train.json.sprites.body[0];
      
      // make the wheels
      for (var i = 0; i < game.train.json.sprites["wheels"].length; i++) {
            const w = document.createElement("img");
            w.id = "wheels"+i;
            w.style.cssText = "position: absolute; z-index:1; left:"+(
                  game.train.json.sprites["wheels"][i][1].position[0]
            )+"px; top:"+(
                  game.train.json.sprites["wheels"][i][1].position[1]
            )+"px;";
    
            w.style.scale = game.train.json.sprites["wheels"][i][1].scale;
            w.src = "main/Trains/"+game.train.json.folder+"/"+game.train.json.sprites["wheels"][i][0];
            
            var spin = 0;
            var wheelsLoop = setInterval(() => {
                  spin += game.train.speed;
                  w.style.transform = "rotate("+spin+"deg)";
            },10);
            
            game.train.data.appendChild(w);
      }

      
      doc.getElementById("body2").appendChild(game.train.data);
      game.train.data.appendChild(t);
      
      var x = 20;
      var station2 = 0;
      var l = setInterval(() => {
            x += 10
      
            // Meter = current position / total distance * total BG length
            const j = (Math.abs(x * 0.5) / ((768 * 0.7) * (game.ligne.json["line-BG length"]))) * (game.ligne.json["line-BG length"]);

            game.train.data.style.left = (x)+"px"
            
            if (station2 <= game.ligne.json.station.length - 1) {
                  // show gui next station 
                  
                  if (game.ligne.json.station[station2][0] == "#object") {
                        station2++;
                  }

                  console.log(station2)
                  if ((j * 0.1) >= (game.ligne.json.station[station2][2].delay + game.ligne.json.station[station2][2].meter)*10) {
                        station2++;
                        x = 0;
                  }
            }
      },10);
}
